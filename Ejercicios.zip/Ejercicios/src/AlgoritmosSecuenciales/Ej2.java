package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej2 {

	public static void main(String[] args) {
		//Determinar el Perímetro de una circunferencia y el área de un círculo.
		 Scanner tc =new Scanner(System.in);
		 double r;
		 System.out.println("Ingrese valor del Radio");
		 r=tc.nextInt();
		 double a=Math.PI*Math.pow(r, 2);
		 double p=2*Math.PI*r;
		 System.out.println("Area= "+a);
		 System.out.println("Perimetro= "+p);

	}

}
