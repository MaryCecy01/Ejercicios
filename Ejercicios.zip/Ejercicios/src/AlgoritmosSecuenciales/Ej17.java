package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej17 {

	public static void main(String[] args) {
		/**
		 * Determinar la energía total que almacena un cuerpo si su energía cinética es 1⁄2 
		 * de la masa por su velocidad al cuadrado y la energía potencial es el producto de la 
		 * masa, altura y la constante de gravedad. Recuerde que ET = EC +EP.
		 */
		
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		double m, v,EP,h;
		double g=9.80665;
		
		System.out.println("Ingrese valor de la masa");
		m=sn.nextDouble();
		System.out.println("Ingrese velocidad");
		v=sn.nextDouble();
		System.out.println("Ingrese valor de la altura");
		h=sn.nextDouble();
		
		double EC=m*Math.pow(v,2);
		       EC=EC/2;
		       
		       EP= m*h*g;
		       
		double ET=EC+EP;
		
		System.out.println("Energia Total= "+ET);
				
		

	}

}
