package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//. Determinar el valor del determinante de segundo orden.
		Scanner tc = new Scanner(System.in);
		
		int a11, a12, a21, a22, det;
		
		System.out.println("Ingrese posición A11");
		a11= tc.nextInt();
		System.out.println("Ingrese posición A12");
		a12 = tc.nextInt();
		System.out.println("Ingrese posición A21");
		a21 = tc.nextInt();
		System.out.println("Ingrese posición A22");
		a22 = tc.nextInt();
		
		det = a11*a22 - (a12*a21);
		
		System.out.println("El determinante de la matriz 2x2 es: " + det);
	tc.close();
		
	}

}
