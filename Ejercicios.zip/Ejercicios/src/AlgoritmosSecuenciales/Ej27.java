package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej27 {

	public static void main(String[] args) {
		/**
		 * Unos pantalones se venden a 10 dólares cada uno si se compran más de tres, 12 dólares
		 * en los demás casos, estructure un programa que lea un número de entrada de pantalones
		 * comprados e imprima el costo total.
		 */
		
		Scanner tc= new Scanner(System.in);
		int cant, cont=0,CT=0;
		
		System.out.println("Ingrese cantidad de pantalones");
		cant=tc.nextInt();
		
		if(cant>3) {
			CT=cant*12;
			System.out.println("Costo Total:"+CT);
		}else {
			CT=cant*10;
		System.out.println("Costo Total:"+CT);
		}

	}

}
