package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej26 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa independiente para cada inciso considerando una lectura de distintos
		 * números tal como se detallan a continuación.
		 * a) XY b) XYZ c) XYZW
		 */
	Scanner tc = new Scanner (System.in);
		int x, y, num;

		System.out.print("Ingrese un número de dos dígitos: ");
		num = tc.nextInt();

		if(num < 10 || num > 99) {
		    System.out.println("El número ingresado no tiene dos dígitos.");
		} else {
		     x = num / 10;
		     y = num % 10;

		    System.out.println("El primer dígito es " + x);
		    System.out.println("El segundo dígito es " + y);
		}


		tc.close();
			}

		}
