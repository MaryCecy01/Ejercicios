package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej22 {

	public static void main(String[] args) {
		/**
		 * Escribir un programa para calcular el interés de una capital conforme a la siguiente
		 * condición. Si el capital prestado es mayor que 10,000 dólares entonces la tasa es del 
		 * 7% en caso contrario del 6%, debe imprimir el capital y su interés.
		 */
		Scanner sn = new Scanner (System.in);
		sn.useLocale(Locale.US);
		
		double IC, C, t;
		
		System.out.println("Ingrese Capital Inicial");
		C=sn.nextDouble();
		System.out.println("Ingrese Periodo de Tiempo");
		t=sn.nextDouble();
		
		
		if (C>10000) {
			IC=C*0.07*t;
			
					
		}else {
			IC=C*0.06*t;
		}
		
		System.out.println("Capital: "+C);
		System.out.println("Interes del Capital: "+IC);

	}

}
