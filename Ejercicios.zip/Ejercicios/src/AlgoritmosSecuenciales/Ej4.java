package AlgoritmosSecuenciales;
import java.util.Locale;
import java.util.Scanner;
public class Ej4 {

	public static void main(String[] args) {
		// Determine la raíz Cuadrada de un número cualquiera.
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
			
		double x;
		System.out.println("Ingrese un numero");
		x= tc.nextDouble();
		
		double r=Math.sqrt(x);
		System.out.println("Raiz= "+r);
		

	}

}
