package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej21 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea un número que verifique si X es negativo que calcule X^4
		 * en caso contrario que calcule X^2.
		 */
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		double x,y,z;
		System.out.println("Ingrese un numero");
		x=sn.nextDouble();
		if(x<0) {
			y=Math.pow(x, 4);
			System.out.println("Es negativo");
			System.out.println(y);
		}else {
			z=Math.pow(x, 2);
			System.out.println("Es positivo");
			System.out.println(z);
		}

	}

}
