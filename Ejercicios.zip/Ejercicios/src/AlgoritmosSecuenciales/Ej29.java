package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej29 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea dos números enteros positivos distintos y escriba la
		 * diferencia entre el mayor y el menor. Asegúrese que su programa escriba por ejemplo 8 si
		 * los números son 10 y 2 o bien 2 y 10.
		 */
		Scanner tc= new Scanner(System.in);
		int num1, num2;
		System.out.println("Ingrese primer numero");
		num1=tc.nextInt();
		System.out.println("Ingrese segundo numero");
		num2=tc.nextInt();
		 if (num1<0||num2<0) {
			 
			 while(num1<0||num2<0) {
			 System.out.println("Ingrese otro numero");
			 num1=tc.nextInt();
			 System.out.println("Ingrese otro numero");
			 num2=tc.nextInt();
			 
			 }
			
			 if(num1>num2) {
				 int D=num1-num2;
				 System.out.println("Diferencia:"+D);
			 }else {
				int  D=num2-num1;
				System.out.println("Diferencia:"+D);
				 
			 }
			 
		 }else {
			 if(num1>num2) {
				 int D=num1-num2;
				 System.out.println("Diferencia:"+D);
			 }else {
				int  D=num2-num1;
				System.out.println("Diferencia:"+D);
		 }
	
		 }

	}

}
