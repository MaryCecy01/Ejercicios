package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej13 {
	
	
	public static void main(String[] args) {
		// Convertir Y yardas, F pies y I pulgadas a Centímetros.
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		double a, b,c;
		double yd=91.44,pie=30.48, cm=2.54;
		String x="Y",y="F",z="I";
		String x1="";		
			
		System.out.println("Ingrese la opcion que desea convertir");
		System.out.println("Y para Yardas \n"+"F para Pies \n"+"I para Pulgadas \n");
		x1=sn.nextLine();
		
		if (x1.equals(x)) {
			System.out.println("Ingrese Yardas");
			a=sn.nextDouble();
			double cm1=a*(yd/1.0);
			System.out.println("Centimetros= "+cm1);
			
		}
		
		if(x1.equals(y)) {
			System.out.println("Ingrese Pies");
			b=sn.nextDouble();
			double cm2=b*(pie/1.0);
			System.out.println("Centimetros= "+cm2);
		}
		
		if (x1.equals(z)) {
			System.out.println("Ingrese Pulgadas");
			c=sn.nextDouble();
			double cm3=c*(cm/1.0);
			System.out.println("Centimetros= "+cm3);
		}
		
		

	}
}


