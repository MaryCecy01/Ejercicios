package AlgoritmosSecuenciales;

import java.util.Scanner;

public class Ej18 {

	public static void main(String[] args) {
		/**Leer un número de tres cifras e imprimirlo en orden invertido Ejemplo Entrada: 567
		 * Salida 765.
		 */
		Scanner tc= new Scanner (System.in);
		int A, C1,C2,C3;
		String c1, c2,c3;
		System.out.println("Digite un numero");
		A= tc.nextInt();
		
		C3=A%10;
		C2=(A/10)%10;
		C1=A/100;
			
		c1=String.valueOf(C1);
		c2=String.valueOf(C2);
		c3=String.valueOf(C3);
		
		System.out.println("Numero al reves:"+c3+c2+c1);
		

	}

}
