package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej23 {

	public static void main(String[] args) {
		/**
		 * Escribir un programa que lea la calificación de un alumno e imprima el mensaje de
		 * aprobado si su calificación es mayor o igual a 60, en caso contrario imprima reprobado.
		 */
		
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		
		double nota;
		
		System.out.println("Ingrese Nota");
		nota=sn.nextDouble();
		
		if (nota>=60) {
			System.out.println("Aprobado");
		}else {
			System.out.println("Reprobado");
		}
		

	}

}
