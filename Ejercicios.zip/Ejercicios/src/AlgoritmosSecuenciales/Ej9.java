package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej9 {

	public static void main(String[] args) {
		// Calcular el volumen de un cilindro conociendo su radio y altura.
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
		double r, h;
		System.out.println("Ingrese radio");
		r=tc.nextInt();
		System.out.println("Ingrese altura");
		h=tc.nextInt();
		
		double v=Math.PI*(Math.pow(r,2)*h);
		
		System.out.println("Volumen:"+v);

	}

}
