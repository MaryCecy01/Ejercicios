package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej28 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea dos números enteros como entrada y escriba el mensaje
		 * signos opuestos si y solo si uno de los enteros es positivo y el otro negativo.
		 */
		Scanner tc= new Scanner(System.in);
		int num1, num2;
		System.out.println("Ingrese primer numero");
		num1=tc.nextInt();
		System.out.println("Ingrese segundo numero");
		num2=tc.nextInt();
		
		if(num1>0 && num2<0 || num1<0 && num2>0) {
			System.out.println("Signos Opuestos");
			
		}else {
			System.out.println("Signos Iguales");
		}
				
	}

}
