package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej1 {

	public static void main(String[] args) {
		/**
		 * Determinar el área de un rectángulo que tiene por base “B” 
		 * y por altura “H”, imprima la base, la altura y su área.*/
		
		Scanner tc= new Scanner(System.in);
		double b, h, a;
		System.out.println("Ingrese Base");
		b=tc.nextInt();
		System.out.println("Ingrese Altura");
		h=tc.nextInt();
		
		a=b*h;
		
		
		
		System.out.println("Base: "+b);
		System.out.println("Altura: "+h);
		System.out.println("Area =  "+a);

	}

}
