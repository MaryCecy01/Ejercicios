package AlgoritmosSecuenciales;

import java.util.Locale;
import java.util.Scanner;

public class Ej30 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que tenga como entrada la lectura de dos números llamados “X” y
		 * “Y” y que imprima una salida que corresponda a cada uno de los pares.
		 * a) (-X, -Y) Entonces sumar los cuadrados de cada componente.
		 * b) (-X, Y) Entonces restar al valor Y el valor de X.
		 * c) (X, -Y) Entonces dividir X entre Y.
		 * d) (X, Y) Entonces verificar si X es mayor que Y, si es así sumarle a X el valor 
		 * de Y, si no obtener la raíz cuadrada de X.
		 */
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		double num1, num2;
		System.out.println("Ingresar primer numero");
		num1=sn.nextDouble();
		System.out.println("Ingresar segundo numero");
		num2=sn.nextDouble();
		
		if (num1>0 && num2>0) {
			if(num1>num2) {
				num1=num1+num2;
				System.out.println("Valor de X= "+num1);
			}  else {
				double r= Math.sqrt(num1);
				System.out.println("Raiz cuadrada="+r);
			}
		}if (num1<0 &&  num2<0) {
				double sum=Math.pow(num1,2)+Math.pow(num2, 2);
				System.out.println("Suma= "+sum);
			}
		
		if (num1>0 && num2<0) {
			double div=num1/num2;
			System.out.println("Division= "+div);
		}
		if(num1<0 && num2>0) {
			num2=num2*num1;
			System.out.println("Resta= "+num2);
		}
		

	}

}
