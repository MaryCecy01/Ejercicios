package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej32 {

	public static void main(String[] args) {
		/**Las calificaciones de los alumnos en un instituto son consideradas de la 
		 * siguiente forma:
		 * a) A es 90 o más.
		 * b) B es al menos 80 pero menos de 90.
		 * c) C es al menos 70 pero menos de 80.
		 * d) D es al menos 65 pero menos de 70.
		 * e) E es menos de 65.
		 * Escriba un programa que considere la entrada de nota en número e imprima 
		 * su codificación en letra.*/
		
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		
		
		double nota;
		
		
		System.out.println("Ingrese nota");
		nota= sn.nextDouble();
		
		while (nota>=101 ||	 nota<=-1) {
			System.out.println("Ingrese una nota dentro del rango");
			nota= sn.nextDouble();
		}
		
		if (nota<=100 && nota>=90) {
			System.out.println("Calificacion es:A");
		}
		if(nota<=90 && nota>=80) {
			System.out.println("Calificacion es:B");
		}
		if(nota<=80 && nota>=70) {
			System.out.println("Calificacion es: C");
		}
		if(nota<=70 && nota>=65) {
			System.out.println("Calificacion es: D");
		}
		
		if(nota<65 && nota>=0) {
			System.out.println("Calificacion es: E");
		
		   
		
		
		}

	}

}
