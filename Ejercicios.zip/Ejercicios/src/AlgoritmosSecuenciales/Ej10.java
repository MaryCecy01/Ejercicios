package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;

public class Ej10 {

	public static void main(String[] args) {
		// Determine el valor de la fuerza de un cuerpo que tiene por masa “M” y aceleración “A”.
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		
		double M,A;
		
		System.out.println("Ingrese Masa");
		M= sn.nextDouble();
		System.out.println("Ingrese Aceleracion");
		A= sn.nextDouble();
		
		double F=M*A;
		System.out.println("Fuerza=" +F);
	}

}
