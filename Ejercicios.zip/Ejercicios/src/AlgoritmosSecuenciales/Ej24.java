package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej24 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea un numero A, si A es un número positivo calcule Y=2^A, 
		 * si es negativo calcule Y=A+5 imprimir el resultado de Y.
		 */
		
		double A, Y;
		
		Scanner sn=  new Scanner(System.in);
		sn.useLocale(Locale.US);
		System.out.println("Ingrese numero");
		A=sn.nextDouble();
		
		if(A>0) {
			Y=Math.pow(2, A);
			System.out.println("Valor de Y: "+Y);
		}else {
			Y=A+5;
			System.out.println("Valor de Y: "+Y);
		}

	}

}
