package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej25 {

	public static void main(String[] args) {
		/**
		 * Escribir un programa que lea un número cualquiera e imprima si el número leído es
		 * divisible por tres.
		 */
		Scanner sn=  new Scanner(System.in);
		sn.useLocale(Locale.US);
		double num;
		System.out.println("Ingrese un numero");
		num=sn.nextDouble();
		
		if(num%3==0) {
			System.out.println("Es divisible por 3");
		}else {
			System.out.println("No es divisible por 3");
		}

	}

}
