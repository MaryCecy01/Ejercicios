package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Determinar las soluciones de N sistema de ecuaciones lineales con dos incógnitas
		//aplicando el método de Cramer.
		//ax + by = c
		//dx + ey = f
		//Donde a,b,c,e,f son números reales.

Scanner tc = new Scanner(System.in);
double R, S, T, U , V, W;
double detS, detX, detY, x, y;
System.out.println("Ec1 (ax + by = c)");
System.out.println("Ingrese el valor de a");
R = tc.nextDouble();
System.out.println("Ingrese el valor de b");
S = tc.nextDouble();
System.out.println("Ingrese el valor de c");
T = tc.nextDouble();

System.out.println("Ec2 (dx + ey = f)");
System.out.println("Ingrese el valor de d");
U = tc.nextDouble();
System.out.println("Ingrese el valor de e");
V = tc.nextDouble();
System.out.println("Ingrese el valor de f");
W = tc.nextDouble();

detS = (R*V)-(U*S);
detX = (V*T)-(W*S);
detY = (R*W)-(U*T);

x = detX/detS;
y = detY/detS;

System.out.println("X = " + x);
System.out.println("Y = " + y);

tc.close();
	}

}
