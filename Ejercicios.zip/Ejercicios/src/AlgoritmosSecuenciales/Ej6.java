package AlgoritmosSecuenciales;
import java.util.Locale;
import java.util.Scanner;
public class Ej6 {

	public static void main(String[] args) {
		// Convertir N kilogramos a Libras.
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
		
		double kl=2.20462;
		double lb;
		
		System.out.println("Ingrese Kilogramos");
	    double x=tc.nextDouble();
		
		lb=(double)x*(kl/1.0);
		
		System.out.println("Conversion a Libras: "+lb);
		

	}

}
