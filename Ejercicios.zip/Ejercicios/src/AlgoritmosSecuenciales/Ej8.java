package AlgoritmosSecuenciales;
import java.util.Locale;
import java.util.Scanner;
public class Ej8 {

	public static void main(String[] args) {
		// Calcular el área de un triángulo conociendo sus tres lados.
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
		double l1, l2, l3;
		double P,S,A;
		System.out.println("Ingrese primer lado");
		l1=tc.nextDouble();
		System.out.println("Ingrese segundo lado");
		l2=tc.nextDouble();
		System.out.println("Ingrese tercer lado");
		l3=tc.nextDouble();
		
		
		P=l1+l2+l3;
		S=P/2;
		A=S*(S-l1)*(S-l2)*(S-l3);
		A=Math.sqrt(A);
	
		System.out.println("Area= "+A);

	}

}
