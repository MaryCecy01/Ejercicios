package AlgoritmosSecuenciales;
import java. util.Scanner; 
import java .util.Locale;
public class Ej31 {

	public static void main(String[] args) {
		/**
		 * UN triángulo es equilátero si posee sus tres lados iguales, es Isósceles 
		 * si tiene solamente dos lados iguales y es escaleno cuando todos sus lados 
		 * son desiguales. Escribir un  programa que lea las dimensiones de los lados 
		 * del triángulo y presente como salida el mensaje de su clasificación de 
		 * triangulo.
		 */
		
		Scanner sn = new Scanner (System.in);
		sn.useLocale(Locale.US);
		double l1, l2,l3;
		System.out.println("Ingrese lado 1");
		l1= sn.nextDouble();
		System.out.println("Ingrese lado 2");
		l2= sn.nextDouble();
		System.out.println("Ingrese lado 3");
		l3= sn.nextDouble();
		
		if (l1==l2 && l2==l3 && l1==l3) {
			System.out.print("\n El triangulo es Equilatero");
			
		}else {
			if (l1==l2 || l1==l3 ||	 l2==l3) {
				System.out.print("\n El triangulo es Isosceles");
			}else {
				System.out.print("\n El triangulo es Escaleno");
			}
		}
		
		
		
		
		

	}

}
