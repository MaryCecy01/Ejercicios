package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej12 {

	public static void main(String[] args) {
		// Obtener el promedio de N notas.
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		int n,i=1;
		double sum=0;
		
	
		System.out.println("Ingrese cantidad de notas");
		n=sn.nextInt();
		
		if (n==0) {
			do {
				System.out.println("Ingrese un numero diferente de cero");
				n=sn.nextInt();
				
			}while(n==0);
			
			 
				while (n>=i) {
			
			System.out.println("Ingrese nota");
		     double x=sn.nextDouble();
		     sum=sum+x;
		     i=i+1;
				
		}
		}else {
			while (n>=i) {
				
				System.out.println("Ingrese nota");
			     double x=sn.nextDouble();
			     sum=sum+x;
			     i=i+1;
		}
		}
		
		double pr=sum/n;
		
		System.out.println("Promedio="+pr);
	}

}
