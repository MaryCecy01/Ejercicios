package AlgoritmosSecuenciales;
import java.util.Locale;
import java.util.Scanner;
public class Ej5 {

	public static void main(String[] args) {
		/**
		 * Evaluar la Función Y= 5X^4 + 2X^3 + 3X^2 + 7 para el valor de
		 * a) X=1;
		 * b) X un número cualquiera.
		 */
		double x;
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
		System.out.println("Ingrese un valor de x ");
		x= tc.nextDouble();
		
		double Y=5*Math.pow(x, 4)+2*Math.pow(x, 3)+3*Math.pow(x,2)+7;
		
		System.out.println("Funcion de Y:"+Y);
	

	}

}
