package AlgoritmosSecuenciales;
import java .util.Scanner;
public class Ej3 {

	public static void main(String[] args) {
		/**
		 * Determine el valor de Y= X*C-2 donde C es una constante con valor C=2.5.
		 * a) Sabiendo que X=2
		 * b) Considerando a X un valor cualquiera.
		 */

		Scanner tc= new Scanner(System.in);
		int x;
		double Y, c=2.5;
		
		System.out.println("Ingrese valor de x");
		x=tc.nextInt();
		
		Y=x*c-2;
		
		System.out.println("Y= "+Y);
		
	}

}
