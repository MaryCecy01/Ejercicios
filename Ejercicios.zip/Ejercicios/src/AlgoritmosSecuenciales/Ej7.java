package AlgoritmosSecuenciales;
import java.util.Locale;
import java.util.Scanner;
public class Ej7 {

	public static void main(String[] args) {
		// Convertir X grados Fahrenheit a grados Celsius. Celsius= 5/9 (Fahrenheit -323).
		Scanner tc= new Scanner(System.in);
		Scanner sn;
		tc=tc.useLocale(Locale.US);
		double F;
		double C;
		System.out.println("Ingrese grados Farenheit");
		F=tc.nextDouble();
		C=F-32;
		C=C*5/9;
		
		System.out.println("Convercion a Grados Celcius: "+ C);

	}

}
