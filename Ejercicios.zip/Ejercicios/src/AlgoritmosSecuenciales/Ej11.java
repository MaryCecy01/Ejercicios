package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;

public class Ej11 {

	public static void main(String[] args) {
		// Obtener el valor del Coseno de un número cualquiera.
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		double x;
		System.out.println("Ingrese numero");
		x=sn.nextDouble();
		
		double cos=Math.cos(x);
		System.out.println("Coseno: "+ cos);
	}

}
