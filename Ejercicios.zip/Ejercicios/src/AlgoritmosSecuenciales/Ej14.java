package AlgoritmosSecuenciales;
import java.util.Scanner;
import java.util.Locale;
public class Ej14 {

	public static void main(String[] args) {
		/**
		 *  Determinar la solución lineal que tiene la forma ax + b =0 donde a y b 
		 *  son números reales.
		 */
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		double a, b,x;
		System.out.println("Ingrese valor de a");
		a=sn.nextDouble();
		System.out.println("Ingrese valor de b");
		b=sn.nextDouble();
		
		x=-b/a;		
		
		System.out.println("Solucion= "+x);
		
		
		
	

	}

}
