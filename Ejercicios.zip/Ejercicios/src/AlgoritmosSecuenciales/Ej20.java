package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej20 {

	public static void main(String[] args) {
		// Escriba un programa que lea un número cualquiera e imprima si es par o impar.
		Scanner tc= new Scanner(System.in);
		int x;
		System.out.println("Ingrese numero");
		x=tc.nextInt();
		
		if (x%2==0) {
			System.out.println("Es par");
		}else {
			System.out.println("Es impar");
		}

	}

}
