package AlgoritmosSecuenciales;
import java.util.Scanner;
public class Ej19 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea la edad de una persona e imprima es votante dado que tiene
		 * 16 o más años de edad.*/
		
		Scanner tc=new Scanner (System.in);
		
		int edad;
		
		
		System.out.println("Ingrese edad");
		edad=tc.nextInt();
		
		
		if (edad>0 && edad<150) {
		if (edad>=16) {
			System.out.println("Es votante");
		}else {
			System.out.println("No es Votante");
		}
		}else {
			do {
			System.out.println("Ingrese una edad valida");
			edad=tc.nextInt();
			
			}while(edad>150||edad<0);
			
			if (edad>=16) {
				System.out.println("Es votante");
			}else {
				System.out.println("No es Votante");
			
			}
			
		}
		}

	}


