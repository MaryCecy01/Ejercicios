package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej35 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que lea tres números cualesquiera y que calcule la suma de ellos y 
		 * su promedio.
		 */
		int i=1;
		int sum=0;
		while(i<=3) {
		int num=(int)Math.floor(Math.random()*100);
		System.out.println(num);
		i=i+1;
		sum=sum+num;
		
		}
		int p=sum/3;
		System.out.println("La suma es: "+sum);
		System.out.println("El promedio es: "+p);
		

	}

}
