package AlgoritmosIterativos;
import java.util.Scanner;
import java.util.Locale;
public class Ej43 {

	public static void main(String[] args) {
		/**
		 * En un curso de 25 alumnos se practican 3 exámenes los datos de cada 
		 * estudiante se registran así: Nombre, Nota1, Nota2, Nota3. Escriba un 
		 * programa que calcule por cada estudiante el promedio de las notas.
		 */
		Scanner tc= new Scanner(System.in);
		tc.useLocale(Locale.US);
		int cant, cont=0;
		double nota1, nota2, nota3,pro=0;
		String p="Promedio de ", y=": ";
		
		
		
		
		System.out.println("Ingrese cantidad de alumnos");
		cant=tc.nextInt();
		
		
		for(int i=1;i<=cant;i++) {
			tc.nextLine();
			System.out.println("Ingrese nombre del alumno");
			String nombre=tc.nextLine();
			tc.nextLine();
			System.out.println("Ingrese nota 1");
			nota1=tc.nextDouble();
			System.out.println("Ingrese nota 2");
			nota2=tc.nextDouble();
			System.out.println("Ingrese nota 3");
			nota3=tc.nextDouble();
			pro=nota1+nota2+nota3;
			pro=pro/3;
			
			System.out.printf("%-10s%-10s\n", "Nombre", "Promedio");
            System.out.printf("%-10s%-10s\n", nombre, pro);
            
		}
		
		
		
		

	}

}
