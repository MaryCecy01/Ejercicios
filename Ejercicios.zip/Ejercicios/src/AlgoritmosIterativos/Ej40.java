package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej40 {

	public static void main(String[] args) {
		/**
		 * Escribir un programa que calcule la factorial de un número entero.
		 * 3! =1’ 2’ 3’=6
		 * 5! =1’ 2’ 3’ 4’ 5’=120
		 */
		
		Scanner tc= new Scanner (System.in);
		int x, f=1;
		
		System.out.println("Ingrese numero");
		x=tc.nextInt();
		
		while(x<0) {
			System.out.println("Ingrese de nuevo un numero valido");
			x=tc.nextInt();
		}
		
		for (int i=1;i<=x;i++) {
			 f=f*i;
		}
				
		System.out.println("Factorial:"+f);

	}

}
