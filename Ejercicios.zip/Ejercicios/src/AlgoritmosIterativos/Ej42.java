package AlgoritmosIterativos;
import java.util.Scanner;
import java.util.Locale;
public class Ej42 {

	public static void main(String[] args) {
		/**
		 * Leer “N” números distintos de 0, si el número leído es positivo súmelo en 
		 * caso contrario cuéntelo.
		 */
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		int cant,cont=0;
		double num,sum=0;
		System.out.println("Ingrese cantidad de numeros");
		cant=sn.nextInt();
		
		
		
		for (int i=1;i<=cant;i++) {
			System.out.println("Ingrese un numero");
			num=sn.nextDouble();
			while(num==0) {
				System.out.println("Ingrese otro numero");
				num=sn.nextDouble();
			}
			
			if (num>0) {
				sum=sum+num;
			}else {
				cont=cont+1;
			}
		}
		System.out.println("Suma de numeros positivos: "+sum);
		System.out.println("Cantidad de numeros negativos: "+cont);

	}

}
