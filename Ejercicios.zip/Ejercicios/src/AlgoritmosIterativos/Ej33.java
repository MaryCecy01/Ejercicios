package AlgoritmosIterativos;

public class Ej33 {

	public static void main(String[] args) {
		//Escriba un programa que imprima los números del 1 al 100.
		
		
		for(int i=1; i<=100;i++) {
		System.out.println(i);
		}
	}

}
