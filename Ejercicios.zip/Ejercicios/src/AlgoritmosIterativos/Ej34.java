package AlgoritmosIterativos;
import java .util.Scanner;
public class Ej34 {

	public static void main(String[] args) {
		// Escriba un programa que lea “n” números enteros y que los imprima.
		Scanner tc=new Scanner(System.in);
		int cant;
		System.out.println("Ingrese n numeros para imprimir");
		cant=tc.nextInt();
		
		for(int i=1; i<=cant;i++){
			System.out.println(i);
		}

	}

}
