package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej36 {

	public static void main(String[] args) {
		// Escriba un programa que lea “n” números que calcule su suma y su promedio.
		Scanner tc= new Scanner (System.in);
		
		
		int cant;
		double sum=0;
		System.out.println("Ingrese cantidad de numeros a leer");
		cant=tc.nextInt();
		
		// Iterador en funcion de i++
		for(int i=1;i<=cant;i++) {
			int num=(int)Math.floor(Math.random()*100);
			System.out.println(num);
			sum=sum+num;
		}
		
	   double p=sum/cant;
		System.out.println("Suma: "+sum);
		System.out.println("Promerdio: "+p);

	}

}
