package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej45 {

	public static void main(String[] args) {
		/**
		 * De una lista de n voltajes escriba el programa que calcule el voltaje mínimo, el voltaje
		 * máximo y el promedio de todos.
		 */
	       Scanner sc = new Scanner(System.in);
	        System.out.print("Ingrese la cantidad de voltajes: ");
	        int n = sc.nextInt();

	        double[] voltajes = new double[n];
	        for (int i = 0; i < n; i++) {
	            System.out.print("Ingrese el voltaje #" + (i+1) + ": ");
	            voltajes[i] = sc.nextDouble();
	        }

	        double min = voltajes[0];
	        double max = voltajes[0];
	        double sum = 0;
	        for (int i = 0; i < n; i++) {
	            if (voltajes[i] < min) {
	                min = voltajes[i];
	            }
	            if (voltajes[i] > max) {
	                max = voltajes[i];
	            }
	            sum += voltajes[i];
	        }

	        double promedio = sum / n;
	        System.out.println("El voltaje mínimo es: " + min);
	        System.out.println("El voltaje máximo es: " + max);
	        System.out.println("El promedio de los voltajes es: " + promedio);
	    
	
	}

}
