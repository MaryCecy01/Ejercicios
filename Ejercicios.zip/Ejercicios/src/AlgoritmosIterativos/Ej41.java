package AlgoritmosIterativos;
import java.util.Scanner;
import java.util.Locale;
public class Ej41 {

	public static void main(String[] args) {
		// Calcule e imprima el producto de “N” números.
		Scanner sn= new Scanner (System.in);
		sn.useLocale(Locale.US);
		
		int x;
		double num, pro=1;
		System.out.println("Ingrese cantidad de numeros");
		x=sn.nextInt();
		
		for (int i=1;i<=x;i++) {
			System.out.println("Ingrese un numero");
			num=sn.nextDouble();
			pro=pro*num;
		}
		System.out.println("Producto= "+pro);

	}

}
