package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej44 {

	public static void main(String[] args) {
		/**
		 * Dada la edad de una persona escriba un programa que imprima “niño” si la edad es menor
		 * que 13 “joven” si la edad es mayor que 13 y menor o igual 25 y “adulto” si la edad es
		 * mayor que 25.
		 */
		Scanner tc= new Scanner(System.in);
		int edad;
		System.out.println("Ingrese edad");
		edad=tc.nextInt();
		
			while(edad<=0 || edad>150) {
				System.out.println("Ingrese edad dentro del rango");
				edad=tc.nextInt();}
			
		
			if(edad<=13) {
				System.out.println("Niño");
			}
			
			if (edad>13 && edad<=25) {
				System.out.println("Joven");
			}
			
			if (edad>25) {
				System.out.println("Adulto");
			}
		}

	}


