package AlgoritmosIterativos;

public class Ej38 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que calcule cuantos números impares hay entre 20 y 100 
		 * e igualmente a cuantos asciende la suma de ellos.
		 */
		int sum=0, cot=0;
		for(int i=20;i<=100;i++) {
			System.out.println(i);
			
			if(i%2!=0) {
				sum=sum+i;
				cot=cot+1;
				
			}
		}
		System.out.println("Cantidad de numeros impares entre 20 y 100: "+cot);
		System.out.println("Suma de numeros impares entre 20 y 100: "+sum);

	}

}
