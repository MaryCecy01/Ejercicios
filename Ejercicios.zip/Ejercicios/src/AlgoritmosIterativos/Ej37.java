package AlgoritmosIterativos;
import java.util.Scanner;
public class Ej37 {

	public static void main(String[] args) {
		/**
		 * Escriba un programa que tenga como entrada “n” números enteros y que calcule el
		 * número de números pares e impares.
		 */
		Scanner tc= new Scanner(System.in);
		int cant, sp=0, si=0;
		System.out.println("Ingresar cantidad");
		cant=tc.nextInt();
		
		for(int i=1;i<=cant;i++) {
			int num=(int)Math.floor(Math.random()*100);
			System.out.println(num);
			
			if(num%2==0) {
			 sp=sp+1;
			}else {
			si=si+1;
			}
		}

		System.out.println("Numero de Pares: "+sp);
		System.out.println("Numero de Impares: "+si);
	}

}
