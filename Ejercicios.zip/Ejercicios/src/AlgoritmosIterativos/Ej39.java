package AlgoritmosIterativos;
import java.util.Scanner;
import java.util.Locale;
public class Ej39 {

	public static void main(String[] args) {
		/**Escriba un programa que lea las notas de “N” alumnos y calcule cuantos aprobados y
		 * desaprobados hay (está aprobado si la nota es mayor de 60).
		 */
		
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		String nombre;
		int cant,count=0,count2=0;
		double nota;
		
		System.out.println("Ingrese cantidad de Alumnos");
		cant=sn.nextInt();
		
		for(int i=1;i<=cant;i++) {
			System.out.println("Ingrese nombre del Alumno");
			nombre=sn.nextLine();
			sn.nextLine();
			System.out.println("Ingrese nota del Alumno");
			nota=sn.nextDouble();
			if(nota>=60) {
				count=count+1;
			
			}else {
				count2=count2+1;
			}
			
		}
		
		System.out.println("Alumnos aprobados: "+count);
		System.out.println("Alumnos reprobados: "+count2);

	}

}
